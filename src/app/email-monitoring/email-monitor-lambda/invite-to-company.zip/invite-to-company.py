import json
import boto3
import email
from email import policy
from email.utils import parseaddr
import re
import requests
from bs4 import BeautifulSoup

def handler(event, context):
    # Parse the SNS message containing the SES email
    sns_message = json.loads(event['Records'][0]['Sns']['Message'])
    email_content = sns_message['content']
    
    # Parse the email with a policy that preserves header case
    msg = email.message_from_string(email_content, policy=policy.SMTP)
    
    # Extract headers
    headers = {
        'from': parseaddr(msg['from'])[1],
        'to': parseaddr(msg['to'])[1],
        'subject': msg['subject'],
        'date': msg['date'],
        'message_id': msg['message-id']
    }
    
    print("Email Headers:", json.dumps(headers, indent=2))
    
    # Check if email is from Intuit
    if headers['from'] != 'do_not_reply@intuit.com':
        print(f"Skipping email from {headers['from']}")
        return {
            'statusCode': 200,
            'body': 'Email skipped - wrong sender'
        }
    
    # Extract email body
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/html":
                body = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8')
                break
    else:
        body = msg.get_payload(decode=True).decode(msg.get_content_charset() or 'utf-8')
    
    # Parse HTML content
    soup = BeautifulSoup(body, 'html.parser')
    
    # Extract company name, email, and invitation link
    company_pattern = r"Company:\s*([^\n]+)"
    email_pattern = r"Email:\s*([\w\.-]+@[\w\.-]+)"
    
    company = re.search(company_pattern, body)
    email_match = re.search(email_pattern, body)
    
    # Find the "Accept invitation" link
    accept_link = None
    for link in soup.find_all('a'):
        if 'Accept' in link.get_text():
            accept_link = link.get('href')
            break
    
    if company and email_match and accept_link:
        result = {
            'headers': headers,
            'extracted_data': {
                'company': company.group(1),
                'email': email_match.group(1),
                'accept_link': accept_link
            }
        }
        print("Extracted data:", json.dumps(result, indent=2))
        
        try:
            # Send GET request to the accept link
            response = requests.get(accept_link, timeout=10)
            response.raise_for_status()
            print(f"Successfully sent GET request to {accept_link}")
            print(f"Response status code: {response.status_code}")
            
            return {
                'statusCode': 200,
                'body': json.dumps(result)
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error sending GET request: {str(e)}")
            raise e
            
    else:
        missing = []
        if not company:
            missing.append("company name")
        if not email_match:
            missing.append("email")
        if not accept_link:
            missing.append("accept link")
            
        error_msg = f"Missing information: {', '.join(missing)}"
        print(error_msg)
        
        return {
            'statusCode': 400,
            'body': json.dumps({
                'headers': headers,
                'error': error_msg
            })
        }